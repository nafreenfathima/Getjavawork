public class Student
	 {
	     private String sname;
	     private int regno;
	  public Student(String name, int regno) {
	   super();
	   this.sname = name;
	   this.regno = regno;
	  }
	  public String getName() {
	   return sname;
	  }
	  public void setName(String name) {
	   this.sname = name;
	  }
	  public int getRegno() {
	   return regno;
	  }
	  public void setRegno(int regno) {
	   this.regno = regno;
	  }
	  public void display() {
	  }

}
