package myio;

public class  {
	import java.util.Scanner;
	class A{
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			int i = sc.nextInt();
			System.out.println(i);
			}
	}

}	
