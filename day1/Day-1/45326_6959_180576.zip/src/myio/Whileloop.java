package myio;

public class Whileloop {

}
