package numbers;


public class Mul {
	public static void main(String[] args) {
	int a = 10;
	int b = 11;
	System.out.println("Binary of 10 = " + Integer.toBinaryString(a));
	System.out.println("Binary of 11 = " + Integer.toBinaryString(b));
	System.out.println("Sum of two Binary numbers = " + Integer.toBinaryString(a) + Integer.toBinaryString(b));

	}
	}
	
		
		
		

