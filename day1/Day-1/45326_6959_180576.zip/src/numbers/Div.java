package numbers;

public class Div {
	public static void main(String[] args)
	{
		int a=5,b=5,c;
		
		
		
		
		
		System.out.println();
		
	}
	
	}


