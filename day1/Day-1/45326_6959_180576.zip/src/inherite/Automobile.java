package inherite;

public interface Automobile { 
	public static final boolean selfdriven=true;
	public abstract boolean selfdriven();

}
