public class CommercialServiceAirport extends Airport {
		 private int noOfpassengersperflight;
		 
		 public int calculatenoOfPassengers(int num,int numpass)
		 {
		  return noOfpassengersperflight=num*numpass;
		  
		 }
		}

