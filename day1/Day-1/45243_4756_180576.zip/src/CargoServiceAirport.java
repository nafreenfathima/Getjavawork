public class CargoServiceAirport extends Airport{
		 private int noOfcargoUnitsperflight;
		 public int calculatenoOfCargounits(int num,int numcar)
		 {
		  return noOfcargoUnitsperflight=num*numcar;
		  
		 }
		}



