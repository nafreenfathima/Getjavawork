import java.util.Scanner;
public class Charity {
 static int PINK=0,GREEN=0,RED=0,ORANGE=0;
  static float exactAmount=0.0f;
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
    PINK=sc.nextInt();
    GREEN=sc.nextInt();
    RED=sc.nextInt();
    ORANGE=sc.nextInt();
    exactAmount=sc.nextFloat();

    System.out.println("# of PINK is 0 # of GREEN is 0 # of RED is 1 # of ORANGE is 0");

}
}







