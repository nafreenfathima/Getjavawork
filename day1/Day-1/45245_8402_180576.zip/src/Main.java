import java.util.Scanner;

	public class Main {

	    public static void main(String[] args) {
	    	//Initializing scanner
			Scanner ke= new Scanner(System.in);       
			System.out.println("Enter the source city:");       
			String source= ke.next();
			System.out.println("Enter the destination city:");
			String destination= ke.next();
			//Get flight company from user
			System.out.println("Enter the flight\r\n1.Air India\r\n2.Indigo"); 
			int pq= Integer.parseInt(ke.next());
			double price;
			if(pq==1) 
			{
				AirIndia ai= new AirIndia();
				price=ai.showFare(source, destination);
				System.out.println("The fare is "+price);
			}
			else if(pq==2)
			{
				
				
				//Create object for class indigo
				Indigo in= new Indigo();
				//Price calculator
				price=in.showFare(source, destination);
				System.out.println("The fare is "+price);
			}
			else
			{
				System.out.println("Invalid Input");
			}
		}

	}

