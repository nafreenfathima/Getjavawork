package numbers;

import java.util.Scanner;

public class Main{
public static void main(String[] args)
{
   Scanner sc=new Scanner(System.in);
   	
  System.out.println("Enter your name");
 System. out.println("Hello! Welcome to Amphi Event Management System");
}
}

