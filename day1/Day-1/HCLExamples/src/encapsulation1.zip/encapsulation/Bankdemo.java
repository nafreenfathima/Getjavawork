package encapsulation;

public class Bankdemo {
	
	

		public static void main(String[] args) {
			Accountt a=new Accountt();
			a.display();
			Baank b=new Baank();
			b.display();
			Branchh br=new Branchh();
			br.display();
			Customerr c=new Customerr();
			c.display();
			Fixedaccountt f= new Fixedaccountt();
			f.display();
			Recurringacc r= new Recurringacc();
			r.display();
			Savingsacc s1= new Savingsacc();
			s1.display();
			Servicenum s2=new Servicenum();
			s2.display();

		}

	}


