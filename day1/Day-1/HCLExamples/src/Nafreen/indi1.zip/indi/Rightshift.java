package arth;

public class Rightshift {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		{
			
			{
				// TODO Auto-generated method stub
				int x=16;
				System.out.println("x=" +x);
				x=x>>2;
				System.out.println("X=" +x);
			}
		}


	}

}
