package Exercises;

public class Employee {

}
