package inherite;
//An interface is
public interface Transport {
	public static final String transportName="public Transport";
	public abstract void bookTicket();
	
}
