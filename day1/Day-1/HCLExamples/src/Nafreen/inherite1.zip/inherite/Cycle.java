package inherite;

public interface Cycle {
	public void balance();

}
