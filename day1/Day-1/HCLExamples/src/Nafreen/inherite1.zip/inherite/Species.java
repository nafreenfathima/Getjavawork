package inherite;

public class Species {
	private boolean living;
	
	Species()
	{
		living=true;
		
	}
	
	public void breathe()
	{
		System.out.println("can brethe");
		
	}

}
