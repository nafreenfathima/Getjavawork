package inherite;

public class Train {
	public class Train implements Transport {
		@Override
		public void bookTicket() {
			// TODO Auto-generated method stub
			System.out.println("Train ticket booked" +transporttime);
		}
		

	}
	
	}

