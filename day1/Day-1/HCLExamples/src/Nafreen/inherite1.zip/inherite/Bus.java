package inherite;

public class Bus implements Transport {

	@Override
	public void bookTicket() {
		// TODO Auto-generated method stub
		System.out.println("bus ticket booked" +transporttime);
	}
	

}
