public class BankFactory {
	 public void getIcici()
		 {
		  System.out.print("ICICI - ");
		  
		 }
		 public void getHdfc()
		 {
		  System.out.print("HDFC - ");
		  
		 }
		}


		