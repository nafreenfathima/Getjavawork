import java.util.Scanner;
public class Main {
	  public static void main(String[] args) {
			
			Scanner x= new Scanner(System.in);
			
			System.out.println("Enter the number of items:");
			int p= x.nextInt();
			
	        x.nextLine();
			System.out.println("Enter the item details in the format(Item Name$Item Type$Item Cost$Item Availability)");
			
			String[] s= new String[p];
			
	        System.out.println("Items:");
			for(int i=0;i<p;i++)
			{
	    
			s[i]=(String) x.nextLine();
			}
			
			for(int j=0;j<p;j++)
			{
			String[] a=s[j].split("\\$");
			Item1 it= new Item1(a[0],a[1],Integer.parseInt(a[2]),Integer.parseInt(a[3]));
			
		    StringBuilder sb= new StringBuilder();
			
			sb.append(it);
			String z=null;
			if(Integer.parseInt(a[3])>0)
			{
			z=new String("Available");
			}
			else
			{
				z=new String("Not Available");
			}
			System.out.print(sb.append(x)+"\n");
			}
			

		}

	}

