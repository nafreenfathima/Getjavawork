public class Staff {
		 private String staffName;
		 private String desig;
		 
		 
		 
		 public Staff(String staffName, String desig) {
		  super();
		  this.staffName = staffName;
		  this.desig = desig;
		 }

		 public String getStaffName() {
		  return staffName;
		 }

		 public void setStaffName(String staffName) {
		  this.staffName = staffName;
		 }

		 public String getDesig() {
		  return desig;
		 }

		 public void setDesig(String desig) {
		  this.desig = desig;
		 }
		    public void display() {
		 }
	}		   

