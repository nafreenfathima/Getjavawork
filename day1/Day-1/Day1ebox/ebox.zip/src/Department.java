public class Department
	{
	 private String deptName;
	 private Staff staff;
	 
	 
	 public Department(String deptName, Staff staff) {
	  super();
	  this.deptName = deptName;
	  this.staff = staff;
	 }

	 public String getDeptName() {
	  return deptName;
	 }

	 public void setDeptName(String deptName) {
	  this.deptName = deptName;
	 }

	 public Staff getStaff() {
	  return staff;
	 }

	 public void setStaff(Staff staff) {
	  this.staff = staff;
	 }
	 public void display()
	 {
	  
	 }
	}

