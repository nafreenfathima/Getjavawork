public class Stall {
	protected String name;
	protected String detail;
	protected String ownerName;
		
		public Stall() {
			super();
		}

		public Stall(String name, String detail, String ownerName) {
			super();
			this.name = name;
			this.detail = detail;
			this.ownerName = ownerName;
		}

		public String getName() {
			return this.name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDetail() {
			return this.detail;
		}

		public void setDetail(String detail) {
			this.detail = detail;
		}

		public String getOwnerName() {
			return this.ownerName;
		}

		public void setOwnerName(String ownerName) {
			this.ownerName = ownerName;
		}
		
		public double computeCost(String stallType, int squareFeet)
		{
			int b;
			switch (stallType)
			{
			case "Platinum": b=200;
			                 break;
			case "Diamond": b=150;
			                 break;
			default: b=100;
			         break;
			}
			
			return b*squareFeet;
		}
		
		public double computeCost(String stallType,int squareFeet,int numberOfTV)
		{
			double b;
			switch (stallType)
			{
			case "Platinum": b=200;
			                 break;
			case "Diamond": b=150;
			                 break;
			default: b=100;
			         break;
			}
			
			return ((b*squareFeet)+(numberOfTV*10000));
		}
		
	}

